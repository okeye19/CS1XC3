/**
 * @file student.h
 * @author Erin Okey
 * @brief This file defines the data type 'Student' and initializes student functions
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */


typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50]; /**< the student's last name */
  char id[11]; /**< the student's ID number */
  double *grades; /**< an array of the student's grades */
  int num_grades; /**< the number of grades the student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
