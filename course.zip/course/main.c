/**
 * @mainpage Student and Course Information
 * 
 * This code contains functions for creating and printing
 * student and course information. This includes:
 * - generating a random student
 * - adding a grade to a student's information
 * - caluculating a student's average
 * - printing a student's information
 * - enrolling a student in a course
 * - printing out a course's information
 * - finding the top student in a course
 * - finding which students are passing a course
 * 
 * 
 * @file main.c
 * @author Erin Okey
 * @brief This file runs student and course functions
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief This function creates a course, enrolls 8 randomly generated students, and prints out the course information.
 * It then finds and prints the top student, then finds the number of passing students and prints them as well.
 * 
 * @return int = 0
 *  
 * 
 *   
 * 
 */

int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
  /**This function first defines a new course,*/

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  /**  then uses a for loop to enroll 20 randomly generated students, each with 8 grades.*/
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);
  /** Then the function finds and prints the top student (i.e. the student with the highest average).*/

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  /** It finally prints the number of students who are passing the course*/
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  /** and generates and prints an array of these students.*/
  
  return 0;
}