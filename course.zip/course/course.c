/**
 * @file course.c
 * @author Erin Okey
 * @brief This file contains functions relating to courses and course information
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Adds a specified student to a specified course
 * 
 * @param course which course are we adding a student to; Course
 * @param student which student are we adding; Student
 * @return void
 * 
 * 
 */

void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student));
  /**The funciton uses realloc if the course already has at least one student; 
   * in this case, the array of students has already been created with calloc.*/ 
  }
  course->students[course->total_students - 1] = *student;
  /** The new student is then added to the array.*/
}

/**
 * @brief Prints out information for specified course incl. name, code, number of students, and information of students
 * 
 * @param course which course are we printing information for; Course
 * @return void
 * 
 * 
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  /**This function first prints name and course code, */
  printf("Total students: %d\n\n", course->total_students);
  /** then prints the total number of students.*/
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
  /** It lastly uses a for loop to print out the information for each student.*/
}

/**
 * @brief Finds and returns the student with the highest average
 * 
 * @param course which course are we finding the top student in; Course
 * @return Student* 
 * 
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  /**The function sets max_average to be the first student's average. */
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }
  /** It then uses a for loop to check the average of each student in the array,
   * and reassigns max_average if a student's average is higher than the current max_average.*/

  return student;
  /** It returns the student with the final max_average. */
}

/**
 * @brief Finds and returns an array of all students who are passing the specified course (i.e. students with an average of at least 50)
 * 
 * @param course which course are we finding passing students in; Course
 * @param total_passing how many students are passing; int pointer
 * @return Student* 
 * 
 * 
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  /**This function uses a for loop to visit each student in the array, and counts how many are passing. */
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }
  /** Another for loop is used to visit each student and, if they are passing, add them to a new array.*/

  *total_passing = count;
  /** The function also reassigns total_passing to the final value of "count"*/

  return passing;
}