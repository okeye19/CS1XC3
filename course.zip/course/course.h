/**
 * @file course.h
 * @author Erin Okey
 * @brief This file defines the data type 'Course' and initializes course functions
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
 
typedef struct _course 
{
  char name[100]; /**< the name of the course */
  char code[10]; /**< the course code */
  Student *students; /**< an array of the students in the course */
  int total_students; /**< the total number of students in the course*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


